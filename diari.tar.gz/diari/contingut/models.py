# -*- coding: utf-8 -*-
from django.db import models
from django.template.defaultfilters import slugify

import datetime
from django.utils.timezone import utc
